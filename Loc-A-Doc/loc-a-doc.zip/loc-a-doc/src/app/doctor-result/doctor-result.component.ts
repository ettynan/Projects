import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-result',
  templateUrl: './doctor-result.component.html',
  styleUrls: ['./doctor-result.component.css']
})
export class DoctorResultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
