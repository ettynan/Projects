import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-pick',
  templateUrl: './doctor-pick.component.html',
  styleUrls: ['./doctor-pick.component.css']
})
export class DoctorPickComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
